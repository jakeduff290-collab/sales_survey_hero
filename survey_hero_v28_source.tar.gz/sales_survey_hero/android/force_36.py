import os, re

path = 'app/build.gradle'
if not os.path.exists(path):
    path = 'app/build.gradle.kts'

with open(path, 'r') as f:
    text = f.read()

text = re.sub(r'compileSdk\s*=\s*\d+', 'compileSdk = 36', text)
text = re.sub(r'targetSdk\s*=\s*\d+', 'targetSdk = 36', text)
text = re.sub(r'compileSdkVersion\s*=?\s*\d+', 'compileSdkVersion = 36', text)
text = re.sub(r'targetSdkVersion\s*=?\s*\d+', 'targetSdkVersion = 36', text)

with open(path, 'w') as f:
    f.write(text)
