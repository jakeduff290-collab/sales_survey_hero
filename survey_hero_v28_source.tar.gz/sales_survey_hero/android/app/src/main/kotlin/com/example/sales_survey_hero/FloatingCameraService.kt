package com.example.sales_survey_hero

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ClipboardManager
import android.content.ClipData
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class FloatingCameraService : Service(), LifecycleOwner {
    private lateinit var windowManager: WindowManager
    private lateinit var camRoot: FrameLayout
    private lateinit var pasteRoot: FrameLayout
    private var photoCapture: androidx.camera.core.ImageCapture? = null
    private lateinit var cameraExecutor: ExecutorService

    private val lifecycleRegistry = LifecycleRegistry(this)
    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)

        cameraExecutor = Executors.newSingleThreadExecutor()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel("hero_cam", "Survey Hero Active", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        startForeground(101, NotificationCompat.Builder(this, "hero_cam").setContentTitle("Survey Hero Active").setSmallIcon(android.R.drawable.ic_menu_camera).build())

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        setupCameraWidget(layoutType)
        setupPasteWidget(layoutType)
    }

    private fun animateClick(view: View) {
        view.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> v.alpha = 0.5f
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.alpha = 1.0f
            }
            false
        }
    }

    private fun setupCameraWidget(layoutType: Int) {
        val camParams = WindowManager.LayoutParams(450, 600, layoutType, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 30; y = 200
        }

        camRoot = FrameLayout(this)
        val expandedView = FrameLayout(this).apply {
            setPadding(12, 12, 12, 12)
            background = GradientDrawable().apply {
                setColor(Color.TRANSPARENT)
                cornerRadius = 45f
                setStroke(6, Color.parseColor("#E2F952"))
            }
        }

        val previewView = androidx.camera.view.PreviewView(this).apply {
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
            outlineProvider = object : android.view.ViewOutlineProvider() {
                override fun getOutline(view: View, outline: android.graphics.Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, 40f)
                }
            }
            clipToOutline = true
        }

        val closeBtn = android.widget.TextView(this).apply {
            text = "✕"
            gravity = Gravity.CENTER
            textSize = 22f
            setTextColor(Color.parseColor("#FF4C4C"))
            background = null
            layoutParams = FrameLayout.LayoutParams(100, 100).apply { gravity = Gravity.TOP or Gravity.START; setMargins(40, 30, 0, 0) }
            setOnClickListener { stopSelf() }
        }

        val galleryBtn = View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.WHITE); setStroke(6, Color.parseColor("#E2F952")) }
            layoutParams = FrameLayout.LayoutParams(100, 100).apply { gravity = Gravity.BOTTOM or Gravity.START; bottomMargin = 40; leftMargin = 40 }
            setOnClickListener { takePhotoForGallery() }
        }

        val extractBtn = View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#E2F952")); setStroke(6, Color.WHITE) }
            layoutParams = FrameLayout.LayoutParams(100, 100).apply { gravity = Gravity.BOTTOM or Gravity.END; bottomMargin = 40; rightMargin = 40 }
            setOnClickListener { takePhoto() }
        }

        val collapsedTab = Button(this).apply {
            text = "▶"
            visibility = View.GONE
            background = GradientDrawable().apply { setColor(Color.parseColor("#E2F952")); cornerRadii = floatArrayOf(0f,0f, 30f,30f, 30f,30f, 0f,0f) }
            layoutParams = FrameLayout.LayoutParams(90, 150)
            setOnClickListener {
                expandedView.visibility = View.VISIBLE
                this.visibility = View.GONE
                camParams.width = 450; camParams.height = 600
                windowManager.updateViewLayout(camRoot, camParams)
            }
        }

        expandedView.addView(previewView)
        expandedView.addView(closeBtn)
        animateClick(galleryBtn)
        expandedView.addView(galleryBtn)
        animateClick(extractBtn)
        expandedView.addView(extractBtn)
        camRoot.addView(expandedView)
        camRoot.addView(collapsedTab)

        var cX = 0; var cY = 0; var cTouchX = 0f; var cTouchY = 0f
        camRoot.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { cX = camParams.x; cY = camParams.y; cTouchX = event.rawX; cTouchY = event.rawY; true }
                MotionEvent.ACTION_MOVE -> {
                    camParams.x = cX + (event.rawX - cTouchX).toInt()
                    camParams.y = cY + (event.rawY - cTouchY).toInt()
                    windowManager.updateViewLayout(camRoot, camParams)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (camParams.x < 50 && expandedView.visibility == View.VISIBLE) {
                        expandedView.visibility = View.GONE
                        collapsedTab.visibility = View.VISIBLE
                        camParams.width = WindowManager.LayoutParams.WRAP_CONTENT; camParams.height = WindowManager.LayoutParams.WRAP_CONTENT; camParams.x = 0
                        windowManager.updateViewLayout(camRoot, camParams)
                    }
                    true
                }
                else -> false
            }
        }
        windowManager.addView(camRoot, camParams)

        val cameraProviderFuture = androidx.camera.lifecycle.ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()
            val preview = androidx.camera.core.Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
            photoCapture = androidx.camera.core.ImageCapture.Builder().build()
            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(this, androidx.camera.core.CameraSelector.DEFAULT_BACK_CAMERA, preview, photoCapture)
            } catch (e: Exception) {}
        }, ContextCompat.getMainExecutor(this))
    }

    private fun setupPasteWidget(layoutType: Int) {
        val pasteParams = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, layoutType, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 30; y = 400
        }

        pasteRoot = FrameLayout(this)
        val expandedView = Button(this).apply {
            text = "📋 PASTE"
            setTextColor(Color.WHITE)
            textSize = 14f
            background = GradientDrawable().apply { setColor(Color.parseColor("#1A1A1A")); cornerRadius = 25f; setStroke(4, Color.parseColor("#E2F952")) }
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, 120)
            setPadding(40, 0, 40, 0)
            setOnClickListener { sendBroadcast(Intent("com.survey_hero.EXECUTE_AUTO_FILL")) }
        }

        val collapsedTab = Button(this).apply {
            text = "◀"
            visibility = View.GONE
            background = GradientDrawable().apply { setColor(Color.parseColor("#E2F952")); cornerRadii = floatArrayOf(30f,30f, 0f,0f, 0f,0f, 30f,30f) }
            layoutParams = FrameLayout.LayoutParams(90, 150)
            setOnClickListener {
                expandedView.visibility = View.VISIBLE
                this.visibility = View.GONE
                pasteParams.x = 30
                windowManager.updateViewLayout(pasteRoot, pasteParams)
            }
        }

        pasteRoot.addView(expandedView)
        pasteRoot.addView(collapsedTab)

        var pX = 0; var pY = 0; var pTouchX = 0f; var pTouchY = 0f
        pasteRoot.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { pX = pasteParams.x; pY = pasteParams.y; pTouchX = event.rawX; pTouchY = event.rawY; false }
                MotionEvent.ACTION_MOVE -> {
                    pasteParams.x = pX - (event.rawX - pTouchX).toInt()
                    pasteParams.y = pY + (event.rawY - pTouchY).toInt()
                    windowManager.updateViewLayout(pasteRoot, pasteParams)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (pasteParams.x < 50 && expandedView.visibility == View.VISIBLE) {
                        expandedView.visibility = View.GONE
                        collapsedTab.visibility = View.VISIBLE
                        pasteParams.x = 0
                        windowManager.updateViewLayout(pasteRoot, pasteParams)
                    }
                    true
                }
                else -> false
            }
        }
        windowManager.addView(pasteRoot, pasteParams)
    }

    private fun takePhoto() {
        Handler(Looper.getMainLooper()).post {
            Toast.makeText(applicationContext, "Extracting...", Toast.LENGTH_SHORT).show()
        }
        val photoFile = File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "scan_${System.currentTimeMillis()}.jpg")
        val outputOptions = androidx.camera.core.ImageCapture.OutputFileOptions.Builder(photoFile).build()

        photoCapture?.takePicture(outputOptions, ContextCompat.getMainExecutor(this),
            object : androidx.camera.core.ImageCapture.OnImageSavedCallback {
                override fun onError(exc: androidx.camera.core.ImageCaptureException) {
                    Handler(Looper.getMainLooper()).post {
                        Toast.makeText(applicationContext, "Capture Failed", Toast.LENGTH_SHORT).show()
                    }
                }
                override fun onImageSaved(output: androidx.camera.core.ImageCapture.OutputFileResults) {
                    try {
                        val image = InputImage.fromFilePath(applicationContext, Uri.fromFile(photoFile))
                        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

                        recognizer.process(image)
                            .addOnSuccessListener { visionText ->
                                val rawText = visionText.text.trim()
                                val formattedText = if (rawText.isNotEmpty()) parseWithPrompt(toTitleCase(rawText)) else "No text detected"

                                Handler(Looper.getMainLooper()).post {
                                    try {
                                        // 1. Gain focus so Android allows Clipboard access
                                        val params = camRoot.layoutParams as WindowManager.LayoutParams
                                        params.flags = params.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
                                        windowManager.updateViewLayout(camRoot, params)

                                        // 2. Load the clipboard
                                        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        val clip = ClipData.newPlainText("Extracted Data", formattedText)
                                        clipboard.setPrimaryClip(clip)

                                        // 3. Return focus to the CRM
                                        params.flags = params.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                                        windowManager.updateViewLayout(camRoot, params)

                                        // 4. Prove it worked
                                        Toast.makeText(applicationContext, "Copied: ${formattedText.take(40)}...", Toast.LENGTH_LONG).show()
                                    } catch (e: Exception) {
                                        Toast.makeText(applicationContext, "Clipboard Error", Toast.LENGTH_LONG).show()
                                    }
                                }
                            }
                            .addOnFailureListener {
                                Handler(Looper.getMainLooper()).post {
                                    Toast.makeText(applicationContext, "OCR Failed", Toast.LENGTH_SHORT).show()
                                }
                            }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            })
    }

    private fun takePhotoForGallery() {
        Handler(Looper.getMainLooper()).post {
            Toast.makeText(applicationContext, "Saving to Gallery...", Toast.LENGTH_SHORT).show()
        }
        val photoFile = File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "gallery_${System.currentTimeMillis()}.jpg")
        val outputOptions = androidx.camera.core.ImageCapture.OutputFileOptions.Builder(photoFile).build()
        photoCapture?.takePicture(outputOptions, ContextCompat.getMainExecutor(this),
            object : androidx.camera.core.ImageCapture.OnImageSavedCallback {
                override fun onError(exc: androidx.camera.core.ImageCaptureException) {
                    Handler(Looper.getMainLooper()).post {
                        Toast.makeText(applicationContext, "Failed to capture", Toast.LENGTH_SHORT).show()
                    }
                }
                override fun onImageSaved(output: androidx.camera.core.ImageCapture.OutputFileResults) {
                    try {
                        val contentValues = ContentValues().apply {
                            put(MediaStore.MediaColumns.DISPLAY_NAME, photoFile.name)
                            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/SurveyHero")
                            }
                        }
                        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
                        if (uri != null) {
                            contentResolver.openOutputStream(uri)?.use { outStream ->
                                photoFile.inputStream().use { inStream -> inStream.copyTo(outStream) }
                            }
                            Handler(Looper.getMainLooper()).post {
                                Toast.makeText(applicationContext, "Saved to Gallery", Toast.LENGTH_SHORT).show()
                            }
                        }
                    } catch (e: Exception) {}
                }
            })
    }

    override fun onDestroy() {
        super.onDestroy()
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        try { windowManager.removeView(camRoot); windowManager.removeView(pasteRoot) } catch (e: Exception) {}
        cameraExecutor.shutdown()
    }

    
    private fun parseWithPrompt(text: String): String {
        // Multi-field extraction matching user prompt templates (e.g., SoCalGas template)
        var name = ""
        var address = ""
        var account = ""
        
        try {
            val accRegex = Regex("Account Number\\s*([\\d\\s]+)", RegexOption.IGNORE_CASE)
            accRegex.find(text)?.let { account = it.groupValues[1].replace(" ", "").trim() }

            val serviceRegex = Regex("Service For\\s*\\n(.*?)\\n(.*?)\\n(.*)", RegexOption.IGNORE_CASE)
            serviceRegex.find(text)?.let { 
                name = it.groupValues[1].trim()
                address = (it.groupValues[2].trim() + ", " + it.groupValues[3].trim()).take(30)
            }
        } catch (e: Exception) {}

        // Fallback if structured tokens aren't found
        if (name.isEmpty() && account.isEmpty()) return text

        // Format fields separated by '||' for sequential accessibility box-filling
        return "$name || $address || $account"
    }

    private fun toTitleCase(text: String): String {
        return text.lowercase().split(" ").joinToString(" ") { word ->
            word.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
        }
    }
}
