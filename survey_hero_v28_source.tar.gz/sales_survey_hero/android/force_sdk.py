import os, re

path = 'app/build.gradle.kts'
if not os.path.exists(path):
    path = 'app/build.gradle'

with open(path, 'r') as f:
    text = f.read()

# Replace any dynamic variables with strict API 34 integers
text = re.sub(r'compileSdk\s*=\s*.*', 'compileSdk = 34', text)
text = re.sub(r'targetSdk\s*=\s*.*', 'targetSdk = 34', text)
text = re.sub(r'compileSdkVersion.*', 'compileSdkVersion = 34', text)
text = re.sub(r'targetSdkVersion.*', 'targetSdkVersion = 34', text)

with open(path, 'w') as f:
    f.write(text)
