import os, re

path = 'app/build.gradle'
if os.path.exists(path + '.kts'): path += '.kts'

with open(path, 'r') as f: 
    text = f.read()

text = re.sub(r'compileSdk\s*=\s*34', 'compileSdk = 36', text)
text = re.sub(r'targetSdk\s*=\s*34', 'targetSdk = 36', text)
text = re.sub(r'compileSdkVersion\s*=\s*34', 'compileSdkVersion = 36', text)
text = re.sub(r'targetSdkVersion\s*=\s*34', 'targetSdkVersion = 36', text)

with open(path, 'w') as f: 
    f.write(text)
