import os

kts_code = """
subprojects {
    afterEvaluate {
        val androidExt = extensions.findByName("android") as? com.android.build.gradle.BaseExtension
        androidExt?.compileSdkVersion(36)
    }
}
"""

groovy_code = """
subprojects {
    afterEvaluate { project ->
        if (project.hasProperty('android')) {
            project.android {
                compileSdkVersion 36
            }
        }
    }
}
"""

if os.path.exists('build.gradle.kts'):
    with open('build.gradle.kts', 'a') as f:
        f.write(kts_code)
elif os.path.exists('build.gradle'):
    with open('build.gradle', 'a') as f:
        f.write(groovy_code)
