import os
kts_code = """
subprojects {
    afterEvaluate {
        val androidExt = extensions.findByName("android") as? com.android.build.gradle.BaseExtension
        androidExt?.compileSdkVersion(36)
    }
}
"""
path = 'build.gradle.kts'
if os.path.exists(path):
    with open(path, 'r') as f:
        data = f.read()
    with open(path, 'w') as f:
        f.write(data.replace(kts_code, ""))
