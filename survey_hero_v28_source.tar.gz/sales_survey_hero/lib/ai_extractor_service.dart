import 'package:google_generative_ai/google_generative_ai.dart';

class AiExtractorService {
  final String apiKey;
  late final GenerativeModel _model;

  AiExtractorService({required this.apiKey}) {
    _model = GenerativeModel(
      model: 'gemini-3.1-pro-preview',
      apiKey: apiKey,
      systemInstruction: Content.system(
        'You are a high-speed data parser for CRM entry. '
        'Extract ONLY the requested fields. '
        'Output format: Return ONLY the exact extracted values, separated by a double pipe "||". '
        'Do not include labels, keys, or any conversational text. '
        'If a field is not found, output an empty space. '
        'Example output: Michael Ramirez||2450 Harbor View Dr||8765432104||1387466'
      ),
    );
  }

  Future<String> extractTargetedData({
    required String rawOcrText,
    required String layoutName,
    required String targetFields,
  }) async {
    if (rawOcrText.trim().isEmpty) return 'No text detected in image.';

    final promptText = 'Target Fields:\n$targetFields\n\n=== RAW OCR TEXT ===\n$rawOcrText\n=== END ===';

    try {
      final response = await _model.generateContent([Content.text(promptText)]);
      return response.text?.trim() ?? 'No response generated.';
    } catch (e) {
      return 'Error: $e';
    }
  }
}
