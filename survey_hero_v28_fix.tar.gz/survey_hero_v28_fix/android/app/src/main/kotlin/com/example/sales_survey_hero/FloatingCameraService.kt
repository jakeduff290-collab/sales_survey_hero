package com.example.sales_survey_hero

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ClipboardManager
import android.content.ClipData
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import com.google.firebase.Firebase
import com.google.firebase.remoteconfig.remoteConfig
import com.google.firebase.remoteconfig.remoteConfigSettings
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class FloatingCameraService : Service(), LifecycleOwner {
    private lateinit var windowManager: WindowManager
    private lateinit var camRoot: FrameLayout
    private lateinit var pasteRoot: FrameLayout
    private var photoCapture: androidx.camera.core.ImageCapture? = null
    private lateinit var cameraExecutor: ExecutorService

    private val lifecycleRegistry = LifecycleRegistry(this)
    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override fun onBind(intent: Intent?): IBinder? = null

    private val remoteConfig by lazy { Firebase.remoteConfig }
    private var extractionPrompt: String = ""

    companion object {
        private const val GEMINI_MODEL = "gemini-3.1-pro-preview"
        private const val DEFAULT_PROMPT = "Extract Full Name, Service Address, and Account Number."
        private const val SYSTEM_INSTRUCTION =
            "You are a high-speed data parser for CRM entry. " +
            "Extract ONLY the fields requested in the instructions given. " +
            "Output format: Return ONLY the exact extracted values, in the same order they were requested, " +
            "separated by a double pipe \"||\". " +
            "Do not include labels, keys, or any conversational text. " +
            "If a field is not found, output an empty space."
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        intent?.getStringExtra("extraction_prompt")?.let { extractionPrompt = it }
        return super.onStartCommand(intent, flags, startId)
    }

    override fun onCreate() {
        super.onCreate()
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)

        cameraExecutor = Executors.newSingleThreadExecutor()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        remoteConfig.setConfigSettingsAsync(remoteConfigSettings { minimumFetchIntervalInSeconds = 3600 })
        remoteConfig.setDefaultsAsync(mapOf("gemini_api_key" to ""))

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel("hero_cam", "Survey Hero Active", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        startForeground(101, NotificationCompat.Builder(this, "hero_cam").setContentTitle("Survey Hero Active").setSmallIcon(android.R.drawable.ic_menu_camera).build())

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        setupCameraWidget(layoutType)
        setupPasteWidget(layoutType)
    }

    private fun animateClick(view: View) {
        view.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> v.alpha = 0.5f
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.alpha = 1.0f
            }
            false
        }
    }

    private fun setupCameraWidget(layoutType: Int) {
        val camParams = WindowManager.LayoutParams(450, 600, layoutType, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 30; y = 200
        }

        camRoot = FrameLayout(this)
        val expandedView = FrameLayout(this).apply {
            setPadding(12, 12, 12, 12)
            background = GradientDrawable().apply {
                setColor(Color.TRANSPARENT)
                cornerRadius = 45f
                setStroke(6, Color.parseColor("#E2F952"))
            }
        }

        val previewView = androidx.camera.view.PreviewView(this).apply {
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
            outlineProvider = object : android.view.ViewOutlineProvider() {
                override fun getOutline(view: View, outline: android.graphics.Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, 40f)
                }
            }
            clipToOutline = true
        }

        val closeBtn = android.widget.TextView(this).apply {
            text = "✕"
            gravity = Gravity.CENTER
            textSize = 22f
            setTextColor(Color.parseColor("#FF4C4C"))
            background = null
            layoutParams = FrameLayout.LayoutParams(100, 100).apply { gravity = Gravity.TOP or Gravity.START; setMargins(40, 30, 0, 0) }
            setOnClickListener { stopSelf() }
        }

        val galleryBtn = View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.WHITE); setStroke(6, Color.parseColor("#E2F952")) }
            layoutParams = FrameLayout.LayoutParams(100, 100).apply { gravity = Gravity.BOTTOM or Gravity.START; bottomMargin = 40; leftMargin = 40 }
            setOnClickListener { takePhotoForGallery() }
        }

        val extractBtn = View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#E2F952")); setStroke(6, Color.WHITE) }
            layoutParams = FrameLayout.LayoutParams(100, 100).apply { gravity = Gravity.BOTTOM or Gravity.END; bottomMargin = 40; rightMargin = 40 }
            setOnClickListener { takePhoto() }
        }

        val collapsedTab = Button(this).apply {
            text = "▶"
            visibility = View.GONE
            background = GradientDrawable().apply { setColor(Color.parseColor("#E2F952")); cornerRadii = floatArrayOf(0f,0f, 30f,30f, 30f,30f, 0f,0f) }
            layoutParams = FrameLayout.LayoutParams(90, 150)
            setOnClickListener {
                expandedView.visibility = View.VISIBLE
                this.visibility = View.GONE
                camParams.width = 450; camParams.height = 600
                windowManager.updateViewLayout(camRoot, camParams)
            }
        }

        expandedView.addView(previewView)
        expandedView.addView(closeBtn)
        animateClick(galleryBtn)
        expandedView.addView(galleryBtn)
        animateClick(extractBtn)
        expandedView.addView(extractBtn)
        camRoot.addView(expandedView)
        camRoot.addView(collapsedTab)

        var cX = 0; var cY = 0; var cTouchX = 0f; var cTouchY = 0f
        camRoot.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { cX = camParams.x; cY = camParams.y; cTouchX = event.rawX; cTouchY = event.rawY; true }
                MotionEvent.ACTION_MOVE -> {
                    camParams.x = cX + (event.rawX - cTouchX).toInt()
                    camParams.y = cY + (event.rawY - cTouchY).toInt()
                    windowManager.updateViewLayout(camRoot, camParams)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (camParams.x < 50 && expandedView.visibility == View.VISIBLE) {
                        expandedView.visibility = View.GONE
                        collapsedTab.visibility = View.VISIBLE
                        camParams.width = WindowManager.LayoutParams.WRAP_CONTENT; camParams.height = WindowManager.LayoutParams.WRAP_CONTENT; camParams.x = 0
                        windowManager.updateViewLayout(camRoot, camParams)
                    }
                    true
                }
                else -> false
            }
        }
        windowManager.addView(camRoot, camParams)

        val cameraProviderFuture = androidx.camera.lifecycle.ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()
            val preview = androidx.camera.core.Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
            photoCapture = androidx.camera.core.ImageCapture.Builder().build()
            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(this, androidx.camera.core.CameraSelector.DEFAULT_BACK_CAMERA, preview, photoCapture)
            } catch (e: Exception) {}
        }, ContextCompat.getMainExecutor(this))
    }

    private fun setupPasteWidget(layoutType: Int) {
        val pasteParams = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, layoutType, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 30; y = 400
        }

        pasteRoot = FrameLayout(this)
        val expandedView = Button(this).apply {
            text = "📋 PASTE"
            setTextColor(Color.WHITE)
            textSize = 14f
            background = GradientDrawable().apply { setColor(Color.parseColor("#1A1A1A")); cornerRadius = 25f; setStroke(4, Color.parseColor("#E2F952")) }
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, 120)
            setPadding(40, 0, 40, 0)
            setOnClickListener { sendBroadcast(Intent("com.survey_hero.EXECUTE_AUTO_FILL")) }
        }

        val collapsedTab = Button(this).apply {
            text = "◀"
            visibility = View.GONE
            background = GradientDrawable().apply { setColor(Color.parseColor("#E2F952")); cornerRadii = floatArrayOf(30f,30f, 0f,0f, 0f,0f, 30f,30f) }
            layoutParams = FrameLayout.LayoutParams(90, 150)
            setOnClickListener {
                expandedView.visibility = View.VISIBLE
                this.visibility = View.GONE
                pasteParams.x = 30
                windowManager.updateViewLayout(pasteRoot, pasteParams)
            }
        }

        pasteRoot.addView(expandedView)
        pasteRoot.addView(collapsedTab)

        var pX = 0; var pY = 0; var pTouchX = 0f; var pTouchY = 0f
        pasteRoot.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { pX = pasteParams.x; pY = pasteParams.y; pTouchX = event.rawX; pTouchY = event.rawY; false }
                MotionEvent.ACTION_MOVE -> {
                    pasteParams.x = pX - (event.rawX - pTouchX).toInt()
                    pasteParams.y = pY + (event.rawY - pTouchY).toInt()
                    windowManager.updateViewLayout(pasteRoot, pasteParams)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (pasteParams.x < 50 && expandedView.visibility == View.VISIBLE) {
                        expandedView.visibility = View.GONE
                        collapsedTab.visibility = View.VISIBLE
                        pasteParams.x = 0
                        windowManager.updateViewLayout(pasteRoot, pasteParams)
                    }
                    true
                }
                else -> false
            }
        }
        windowManager.addView(pasteRoot, pasteParams)
    }

    private fun takePhoto() {
        Handler(Looper.getMainLooper()).post {
            Toast.makeText(applicationContext, "Extracting...", Toast.LENGTH_SHORT).show()
        }
        val photoFile = File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "scan_${System.currentTimeMillis()}.jpg")
        val outputOptions = androidx.camera.core.ImageCapture.OutputFileOptions.Builder(photoFile).build()

        photoCapture?.takePicture(outputOptions, ContextCompat.getMainExecutor(this),
            object : androidx.camera.core.ImageCapture.OnImageSavedCallback {
                override fun onError(exc: androidx.camera.core.ImageCaptureException) {
                    Handler(Looper.getMainLooper()).post {
                        Toast.makeText(applicationContext, "Capture Failed", Toast.LENGTH_SHORT).show()
                    }
                }
                override fun onImageSaved(output: androidx.camera.core.ImageCapture.OutputFileResults) {
                    try {
                        val image = InputImage.fromFilePath(applicationContext, Uri.fromFile(photoFile))
                        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

                        recognizer.process(image)
                            .addOnSuccessListener { visionText ->
                                val rawText = visionText.text.trim()
                                if (rawText.isEmpty()) {
                                    Handler(Looper.getMainLooper()).post {
                                        Toast.makeText(applicationContext, "No text detected", Toast.LENGTH_SHORT).show()
                                    }
                                    return@addOnSuccessListener
                                }

                                extractWithGemini(rawText, extractionPrompt) { formattedText, usedFallback ->
                                    Handler(Looper.getMainLooper()).post {
                                        try {
                                            // 1. Gain focus so Android allows Clipboard access
                                            val params = camRoot.layoutParams as WindowManager.LayoutParams
                                            params.flags = params.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
                                            windowManager.updateViewLayout(camRoot, params)

                                            // 2. Load the clipboard
                                            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                            val clip = ClipData.newPlainText("Extracted Data", formattedText)
                                            clipboard.setPrimaryClip(clip)

                                            // 3. Return focus to the CRM
                                            params.flags = params.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                                            windowManager.updateViewLayout(camRoot, params)

                                            // 4. Prove it worked
                                            val label = if (usedFallback) "Copied (offline mode): " else "Copied: "
                                            Toast.makeText(applicationContext, "$label${formattedText.take(40)}...", Toast.LENGTH_LONG).show()
                                        } catch (e: Exception) {
                                            Toast.makeText(applicationContext, "Clipboard Error", Toast.LENGTH_LONG).show()
                                        }
                                    }
                                }
                            }
                            .addOnFailureListener {
                                Handler(Looper.getMainLooper()).post {
                                    Toast.makeText(applicationContext, "OCR Failed", Toast.LENGTH_SHORT).show()
                                }
                            }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            })
    }

    private fun takePhotoForGallery() {
        Handler(Looper.getMainLooper()).post {
            Toast.makeText(applicationContext, "Saving to Gallery...", Toast.LENGTH_SHORT).show()
        }
        val photoFile = File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "gallery_${System.currentTimeMillis()}.jpg")
        val outputOptions = androidx.camera.core.ImageCapture.OutputFileOptions.Builder(photoFile).build()
        photoCapture?.takePicture(outputOptions, ContextCompat.getMainExecutor(this),
            object : androidx.camera.core.ImageCapture.OnImageSavedCallback {
                override fun onError(exc: androidx.camera.core.ImageCaptureException) {
                    Handler(Looper.getMainLooper()).post {
                        Toast.makeText(applicationContext, "Failed to capture", Toast.LENGTH_SHORT).show()
                    }
                }
                override fun onImageSaved(output: androidx.camera.core.ImageCapture.OutputFileResults) {
                    try {
                        val contentValues = ContentValues().apply {
                            put(MediaStore.MediaColumns.DISPLAY_NAME, photoFile.name)
                            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/SurveyHero")
                            }
                        }
                        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
                        if (uri != null) {
                            contentResolver.openOutputStream(uri)?.use { outStream ->
                                photoFile.inputStream().use { inStream -> inStream.copyTo(outStream) }
                            }
                            Handler(Looper.getMainLooper()).post {
                                Toast.makeText(applicationContext, "Saved to Gallery", Toast.LENGTH_SHORT).show()
                            }
                        }
                    } catch (e: Exception) {}
                }
            })
    }

    override fun onDestroy() {
        super.onDestroy()
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        try { windowManager.removeView(camRoot); windowManager.removeView(pasteRoot) } catch (e: Exception) {}
        cameraExecutor.shutdown()
    }

    /**
     * Extracts fields using Gemini, driven by whatever the user typed in the
     * "Extraction Prompt" box (passed in as [prompt]). Calls back on a
     * background thread with (result, usedFallback) — usedFallback is true
     * only if Gemini couldn't be reached (no key set / no network / API error),
     * in which case we fall back to the old fixed-template regex parser so the
     * app doesn't hard-fail in the field.
     */
    private fun extractWithGemini(rawOcrText: String, prompt: String, callback: (String, Boolean) -> Unit) {
        remoteConfig.fetchAndActivate().addOnCompleteListener {
            val apiKey = remoteConfig.getString("gemini_api_key")
            if (apiKey.isBlank()) {
                callback(parseWithFixedTemplate(toTitleCase(rawOcrText)), true)
                return@addOnCompleteListener
            }
            cameraExecutor.execute {
                val result = callGeminiApi(apiKey, rawOcrText, prompt)
                if (result != null) {
                    callback(result, false)
                } else {
                    callback(parseWithFixedTemplate(toTitleCase(rawOcrText)), true)
                }
            }
        }
    }

    private fun callGeminiApi(apiKey: String, rawOcrText: String, prompt: String): String? {
        return try {
            val fieldInstruction = if (prompt.isNotBlank()) prompt else DEFAULT_PROMPT
            val promptText = "Instructions:\n$fieldInstruction\n\n=== RAW OCR TEXT ===\n$rawOcrText\n=== END ==="
            val requestBody = JSONObject().apply {
                put("system_instruction", JSONObject().apply {
                    put("parts", JSONArray().put(JSONObject().put("text", SYSTEM_INSTRUCTION)))
                })
                put("contents", JSONArray().put(JSONObject().apply {
                    put("parts", JSONArray().put(JSONObject().put("text", promptText)))
                }))
            }

            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$GEMINI_MODEL:generateContent?key=$apiKey")
            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "POST"
            connection.setRequestProperty("Content-Type", "application/json")
            connection.doOutput = true
            connection.connectTimeout = 15000
            connection.readTimeout = 15000
            connection.outputStream.use { it.write(requestBody.toString().toByteArray()) }

            val responseCode = connection.responseCode
            val stream = if (responseCode in 200..299) connection.inputStream else connection.errorStream
            val responseText = stream.bufferedReader().use { it.readText() }
            if (responseCode !in 200..299) return null

            JSONObject(responseText)
                .getJSONArray("candidates")
                .getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")
                .getJSONObject(0)
                .getString("text")
                .trim()
        } catch (e: Exception) {
            null
        }
    }

    /** Offline-only fallback: fixed regex match for one specific utility-bill layout. */
    private fun parseWithFixedTemplate(text: String): String {
        var name = ""
        var address = ""
        var account = ""
        
        try {
            val accRegex = Regex("Account Number\\s*([\\d\\s]+)", RegexOption.IGNORE_CASE)
            accRegex.find(text)?.let { account = it.groupValues[1].replace(" ", "").trim() }

            val serviceRegex = Regex("Service For\\s*\\n(.*?)\\n(.*?)\\n(.*)", RegexOption.IGNORE_CASE)
            serviceRegex.find(text)?.let { 
                name = it.groupValues[1].trim()
                address = (it.groupValues[2].trim() + ", " + it.groupValues[3].trim()).take(30)
            }
        } catch (e: Exception) {}

        // Fallback if structured tokens aren't found
        if (name.isEmpty() && account.isEmpty()) return text

        // Format fields separated by '||' for sequential accessibility box-filling
        return "$name || $address || $account"
    }

    private fun toTitleCase(text: String): String {
        return text.lowercase().split(" ").joinToString(" ") { word ->
            word.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
        }
    }
}
