package com.example.sales_survey_hero

import android.content.Intent
import android.os.Build
import android.provider.Settings
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity: FlutterActivity() {
    private val CHANNEL = "com.survey_hero/camera_overlay"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            if (call.method == "startService") {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                    val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
                    startActivity(intent)
                    result.error("PERMISSION_DENIED", "Overlay permission required", null)
                } else {
                    val intent = Intent(this, FloatingCameraService::class.java)
                    val prompt = call.argument<String>("prompt")
                    if (!prompt.isNullOrBlank()) {
                        intent.putExtra("extraction_prompt", prompt)
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        startForegroundService(intent)
                    } else {
                        startService(intent)
                    }
                    result.success(true)
                }
            } else if (call.method == "stopService") {
                stopService(Intent(this, FloatingCameraService::class.java))
                result.success(true)
            } else {
                result.notImplemented()
            }
        }
    }
}
